package com.example.projectcontacts

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.PopupWindow
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.projectcontacts.viewmodels.ContactAdapter
import com.example.projectcontacts.database.Contact
import com.example.projectcontacts.viewmodels.MainModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var model : MainModel
    private lateinit var listView: ListView
    private lateinit var adapter: ContactAdapter
    private val contactList = ArrayList<Contact>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        model = MainModel(this)

        listView = findViewById(R.id.contactsLV)
        adapter = ContactAdapter(this, contactList)
        fetchAndPopulateList()

        val addContactBtn: Button = findViewById(R.id.addBtn)
        addContactBtn.setOnClickListener {
            showAddContactPopup()
        }

        val searchEditText: EditText = findViewById(R.id.searchEditText)
        val searchButton: Button = findViewById(R.id.searchButton)

        searchButton.setOnClickListener {
            val query = searchEditText.text.toString()
            if (query.isNotBlank()) {
                model.searchContacts(this, query) { results ->
                    contactList.clear()
                    contactList.addAll(results)
                    adapter.notifyDataSetChanged()
                }
            } else {
                fetchAndPopulateList()
            }
        }

    }

    private fun fetchAndPopulateList() {
        lifecycleScope.launch {
            val contacts = withContext(Dispatchers.IO) {
                model.fetchAllContacts(baseContext)
            }

            contactList.clear()
            contactList.addAll(contacts)
            adapter.notifyDataSetChanged()
            listView.adapter = adapter
        }
    }

    private fun showAddContactPopup() {
        val inflater = LayoutInflater.from(this)
        val popupView = inflater.inflate(R.layout.add_contact_layout, null)
        val popupWindow = PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)

        val nameInput = popupView.findViewById<EditText>(R.id.addNameET)
        val phoneInput = popupView.findViewById<EditText>(R.id.addPhoneET)
        val saveContactBtn = popupView.findViewById<Button>(R.id.addPopUpBtn)

        saveContactBtn.setOnClickListener {
            val name = nameInput.text.toString()
            val phone = phoneInput.text.toString()

            try {
                model.addContact(this, name, phone) {
                    fetchAndPopulateList()
                    popupWindow.dismiss()
                }
            } catch (e: IllegalArgumentException) {
                Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
            }
        }

        popupWindow.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.popup_background))
        popupWindow.isOutsideTouchable = true
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0)
    }


}