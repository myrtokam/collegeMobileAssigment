package com.example.projectcontacts.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

//Dao -> Data access object
@Dao
interface ContactDao {
    @Insert
    suspend fun insertContact(contact : Contact)

    @Query("SELECT * FROM contacts ORDER BY name ASC")
    suspend fun getAllContacts(): List<Contact>

    @Query("SELECT * FROM contacts WHERE name LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' ORDER BY name ASC")
    suspend fun searchContacts(query: String): List<Contact>

    @Update
    suspend fun updateContact(contact : Contact)

    @Query("SELECT * FROM contacts where name LIKE :name")
    suspend fun searchContactByName(name : String) : List<Contact>

    @Query("SELECT * FROM contacts where id = :id")
    suspend fun searchContactById(id : Int) : Contact

    @Delete
    suspend fun deleteContact(contact : Contact)
}